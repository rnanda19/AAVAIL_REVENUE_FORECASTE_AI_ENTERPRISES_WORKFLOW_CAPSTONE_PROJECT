import requests

# ============================================================
# BASE URL
# ============================================================

base_url = "http://127.0.0.1:5000"

print("=" * 80)
print("API UNIT TESTING")
print("=" * 80)

# ============================================================
# TEST 1 — HOME ENDPOINT
# ============================================================

try:

    response = requests.get(base_url)

    print("\nTEST 1 — HOME ENDPOINT")

    print(f"Status Code : {response.status_code}")

    print("Response:")

    print(response.json())

except Exception as e:

    print(f"TEST FAILED : {e}")

# ============================================================
# TEST 2 — HEALTH ENDPOINT
# ============================================================

try:

    response = requests.get(f"{base_url}/health")

    print("\nTEST 2 — HEALTH ENDPOINT")

    print(f"Status Code : {response.status_code}")

    print("Response:")

    print(response.json())

except Exception as e:

    print(f"TEST FAILED : {e}")

# ============================================================
# TEST 3 — PREDICT ENDPOINT
# ============================================================

prediction_input = {

    "Lag_1": 5000,
    "Lag_7": 7000,
    "Lag_14": 6500,
    "Rolling_Mean_7": 6200,
    "Rolling_STD_7": 500,
    "Month": 6,
    "Quarter": 2,
    "Weekday": 3,
    "DayOfYear": 180,
    "Country_Code": 5
}

try:

    response = requests.post(
        f"{base_url}/predict",
        json=prediction_input
    )

    print("\nTEST 3 — PREDICT ENDPOINT")

    print(f"Status Code : {response.status_code}")

    print("Prediction Response:")

    print(response.json())

except Exception as e:

    print(f"TEST FAILED : {e}")

# ============================================================
# TEST 4 — GOVERNANCE ENDPOINT
# ============================================================

try:

    response = requests.get(f"{base_url}/governance")

    print("\nTEST 4 — GOVERNANCE ENDPOINT")

    print(f"Status Code : {response.status_code}")

    print("Response:")

    print(response.json())

except Exception as e:

    print(f"TEST FAILED : {e}")

print("\n" + "=" * 80)
print("ALL API TESTS COMPLETED")
print("=" * 80)