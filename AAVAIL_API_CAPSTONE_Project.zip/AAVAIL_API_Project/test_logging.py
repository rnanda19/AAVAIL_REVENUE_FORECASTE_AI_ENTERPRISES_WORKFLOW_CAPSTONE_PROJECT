import os

# ============================================================
# LOGS FOLDER
# ============================================================

logs_folder = r"C:/Users/rnand/Downloads/AAVAIL_API_Project/logs"

print("=" * 80)
print("LOGGING UNIT TESTING")
print("=" * 80)

# ============================================================
# REQUIRED LOG FILES
# ============================================================

required_logs = [

    "monitoring_logs.csv",
    "drift_alerts.csv",
    "api_request_logs.csv",
    "prediction_history.csv",
    "governance_audit.csv"
]

# ============================================================
# TEST LOG FILES
# ============================================================

for log_file in required_logs:

    file_path = os.path.join(
        logs_folder,
        log_file
    )

    print(f"\nChecking : {log_file}")

    if os.path.exists(file_path):

        print("STATUS : FOUND")

    else:

        print("STATUS : MISSING")

print("\n" + "=" * 80)
print("LOGGING TESTING COMPLETED")
print("=" * 80)