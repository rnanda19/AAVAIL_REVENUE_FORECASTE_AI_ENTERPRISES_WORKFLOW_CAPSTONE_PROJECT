from flask import Flask, request, jsonify
import pandas as pd
import joblib
import os
from datetime import datetime

# ============================================================
# LOAD MODEL
# ============================================================

model = joblib.load("revenue_forecast_model.pkl")

# ============================================================
# CREATE APP
# ============================================================

app = Flask(__name__)

# ============================================================
# LOGGING PATHS
# ============================================================

project_folder = r"C:/Users/rnand/Downloads/AAVAIL_API_Project"

logs_folder = os.path.join(
    project_folder,
    "logs"
)

os.makedirs(logs_folder, exist_ok=True)

api_logs_file = os.path.join(
    logs_folder,
    "api_request_logs.csv"
)

prediction_logs_file = os.path.join(
    logs_folder,
    "prediction_history.csv"
)

error_logs_file = os.path.join(
    logs_folder,
    "error_logs.csv"
)

governance_logs_file = os.path.join(
    logs_folder,
    "governance_audit.csv"
)

# ============================================================
# HOME ROUTE
# ============================================================

@app.route("/")
def home():

    return jsonify({
        "message": "IBM AAVAIL Forecasting API Running"
    })

# ============================================================
# HEALTH CHECK
# ============================================================

@app.route("/health")
def health():

    return jsonify({
        "status": "healthy"
    })

# ============================================================
# PREDICTION ROUTE
# ============================================================

@app.route("/predict", methods=["POST"])
def predict():

    try:

        # ====================================================
        # INPUT DATA
        # ====================================================

        data = request.json

        input_df = pd.DataFrame([data])

        # ====================================================
        # PREDICTION
        # ====================================================

        prediction = model.predict(input_df)

        prediction_value = float(prediction[0])

        # ====================================================
        # API REQUEST LOG
        # ====================================================

        api_log = pd.DataFrame({
            "Timestamp": [datetime.now()],
            "Endpoint": ["/predict"],
            "Request_Status": ["SUCCESS"]
        })

        if os.path.exists(api_logs_file):

            api_log.to_csv(
                api_logs_file,
                mode='a',
                header=False,
                index=False
            )

        else:

            api_log.to_csv(
                api_logs_file,
                index=False
            )

        # ====================================================
        # PREDICTION HISTORY LOG
        # ====================================================

        prediction_log = pd.DataFrame({
            "Timestamp": [datetime.now()],
            "Predicted_Revenue": [prediction_value]
        })

        if os.path.exists(prediction_logs_file):

            prediction_log.to_csv(
                prediction_logs_file,
                mode='a',
                header=False,
                index=False
            )

        else:

            prediction_log.to_csv(
                prediction_logs_file,
                index=False
            )

        # ====================================================
        # GOVERNANCE AUDIT LOG
        # ====================================================

        governance_log = pd.DataFrame({
            "Timestamp": [datetime.now()],
            "Model_Name": ["Random Forest Revenue Forecasting"],
            "Action": ["Prediction Generated"],
            "Governance_Status": ["Compliant"]
        })

        if os.path.exists(governance_logs_file):

            governance_log.to_csv(
                governance_logs_file,
                mode='a',
                header=False,
                index=False
            )

        else:

            governance_log.to_csv(
                governance_logs_file,
                index=False
            )

        # ====================================================
        # RETURN RESPONSE
        # ====================================================

        return jsonify({
            "predicted_revenue": prediction_value
        })

    except Exception as e:

        # ====================================================
        # ERROR LOGGING
        # ====================================================

        error_log = pd.DataFrame({
            "Timestamp": [datetime.now()],
            "Error_Message": [str(e)]
        })

        if os.path.exists(error_logs_file):

            error_log.to_csv(
                error_logs_file,
                mode='a',
                header=False,
                index=False
            )

        else:

            error_log.to_csv(
                error_logs_file,
                index=False
            )

        return jsonify({
            "error": str(e)
        })

# ============================================================
# TRAIN ROUTE
# ============================================================

@app.route("/train")
def train():

    return jsonify({
        "message": "Retraining Trigger Simulated"
    })

# ============================================================
# LOGFILE ROUTE
# ============================================================

@app.route("/logfile")
def logfile():

    return jsonify({
        "message": "Enterprise Logs Available"
    })

# ============================================================
# GOVERNANCE ROUTE
# ============================================================

@app.route("/governance")
def governance():

    return jsonify({
        "message": "Governance Audit Active"
    })

# ============================================================
# RUN APPLICATION
# ============================================================

if __name__ == "__main__":

    app.run(
        debug=True,
        host="0.0.0.0",
        port=5000
    )