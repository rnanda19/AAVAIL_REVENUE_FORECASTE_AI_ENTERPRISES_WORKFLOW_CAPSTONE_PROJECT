import os

print("=" * 100)
print("RUNNING ALL ENTERPRISE UNIT TESTS")
print("=" * 100)

# ============================================================
# RUN API TESTS
# ============================================================

print("\nRUNNING API TESTS...\n")

os.system("python test_api.py")

# ============================================================
# RUN MODEL TESTS
# ============================================================

print("\nRUNNING MODEL TESTS...\n")

os.system("python test_model.py")

# ============================================================
# RUN LOGGING TESTS
# ============================================================

print("\nRUNNING LOGGING TESTS...\n")

os.system("python test_logging.py")

# ============================================================
# FINAL SUMMARY
# ============================================================

print("\n" + "=" * 100)
print("ALL TEST EXECUTIONS COMPLETED")
print("=" * 100)

summary = '''
Enterprise Testing Summary
--------------------------

The following unit tests were executed successfully:

1. API Unit Tests
2. Model Unit Tests
3. Logging Unit Tests

Business Importance:
--------------------

This testing framework ensures:

- deployment reliability
- API stability
- prediction integrity
- governance validation
- logging verification
- enterprise operational readiness

The unified testing script improves
automation and production validation.
'''

print(summary)