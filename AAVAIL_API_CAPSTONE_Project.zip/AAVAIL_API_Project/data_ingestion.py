import pandas as pd

# ============================================================
# DATA INGESTION FUNCTION
# ============================================================

def load_data():

    file_path = r"c:\Users\rnand\Downloads\online+retail\Online Retail.xlsx"

    retail_df = pd.read_excel(file_path)

    print("=" * 80)
    print("DATA INGESTION COMPLETED")
    print("=" * 80)

    print("\nDataset Loaded Successfully")

    print(f"\nTotal Rows : {retail_df.shape[0]:,}")

    print(f"Total Columns : {retail_df.shape[1]}")

    print("\nColumn Names:")

    print(retail_df.columns.tolist())

    return retail_df

# ============================================================
# MAIN EXECUTION
# ============================================================

if __name__ == "__main__":

    retail_df = load_data()