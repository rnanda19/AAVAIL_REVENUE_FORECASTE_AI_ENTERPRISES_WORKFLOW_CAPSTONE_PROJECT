import os
import pandas as pd
import numpy as np
from datetime import datetime

# ============================================================
# OUTPUT PATHS
# ============================================================

project_folder = r"C:/Users/rnand/Downloads/AAVAIL_API_Project"

logs_folder = os.path.join(
    project_folder,
    "logs"
)

os.makedirs(logs_folder, exist_ok=True)

monitoring_file = os.path.join(
    logs_folder,
    "monitoring_logs.csv"
)

alerts_file = os.path.join(
    logs_folder,
    "drift_alerts.csv"
)

# ============================================================
# SIMULATED ENTERPRISE PREDICTIONS
# ============================================================

np.random.seed(42)

actual_revenue = np.random.normal(
    loc=10000,
    scale=1500,
    size=100
)

predicted_revenue = actual_revenue + np.random.normal(
    loc=0,
    scale=800,
    size=100
)

# ============================================================
# ERROR CALCULATIONS
# ============================================================

absolute_errors = np.abs(
    actual_revenue - predicted_revenue
)

squared_errors = (
    actual_revenue - predicted_revenue
) ** 2

mae = np.mean(absolute_errors)

rmse = np.sqrt(np.mean(squared_errors))

# ============================================================
# MONITORING DATAFRAME
# ============================================================

monitoring_df = pd.DataFrame({
    "Timestamp": [
        datetime.now()
    ] * 100,
    "Actual_Revenue": actual_revenue,
    "Predicted_Revenue": predicted_revenue,
    "Absolute_Error": absolute_errors,
    "Squared_Error": squared_errors
})

# ============================================================
# SAVE MONITORING LOGS
# ============================================================

monitoring_df.to_csv(
    monitoring_file,
    index=False
)

# ============================================================
# DRIFT DETECTION
# ============================================================

rmse_threshold = 1200
mae_threshold = 900

alerts = []

if rmse > rmse_threshold:

    alerts.append({
        "Timestamp": datetime.now(),
        "Alert_Type": "RMSE Drift",
        "Observed_Value": rmse,
        "Threshold": rmse_threshold,
        "Recommendation": "Trigger model retraining"
    })

if mae > mae_threshold:

    alerts.append({
        "Timestamp": datetime.now(),
        "Alert_Type": "MAE Drift",
        "Observed_Value": mae,
        "Threshold": mae_threshold,
        "Recommendation": "Investigate prediction degradation"
    })

# ============================================================
# SAVE ALERTS
# ============================================================

alerts_df = pd.DataFrame(alerts)

alerts_df.to_csv(
    alerts_file,
    index=False
)

# ============================================================
# ENTERPRISE MONITORING REPORT
# ============================================================

print("=" * 100)
print("ENTERPRISE FORECAST MONITORING SYSTEM")
print("=" * 100)

print(f"\nMean Absolute Error (MAE) : {mae:,.2f}")
print(f"Root Mean Squared Error (RMSE) : {rmse:,.2f}")

print("\nMonitoring Logs Saved Successfully")
print(monitoring_file)

print("\nDrift Alerts Saved Successfully")
print(alerts_file)

print("\nENTERPRISE MONITORING STORY")
print("-" * 100)

story = f'''
The monitoring framework continuously evaluates
forecasting degradation in production.

Current MAE:
{mae:,.2f}

Current RMSE:
{rmse:,.2f}

Business Interpretation:
------------------------

The enterprise monitoring framework helps:
- detect forecasting degradation
- identify model drift
- improve governance
- support retraining decisions
- maintain enterprise forecasting reliability

Drift thresholds ensure the organization can
proactively retrain the forecasting model
before significant operational degradation occurs.
'''

print(story)

# ============================================================
# MONITORING VISUALIZATION
# ============================================================

import matplotlib.pyplot as plt

plt.figure(figsize=(16, 7))

plt.plot(
    monitoring_df['Absolute_Error'],
    color='red',
    linewidth=2
)

plt.title(
    'Enterprise Forecast Error Monitoring',
    fontsize=22,
    fontweight='bold'
)

plt.xlabel('Observation Number')
plt.ylabel('Absolute Error')

plt.grid(alpha=0.3)

chart_path = os.path.join(
    logs_folder,
    "forecast_monitoring_chart.png"
)

plt.savefig(
    chart_path,
    bbox_inches='tight',
    dpi=300
)

plt.show()

print("\nMonitoring Chart Saved Successfully")
print(chart_path)