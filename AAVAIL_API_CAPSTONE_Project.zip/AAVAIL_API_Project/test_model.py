import joblib
import pandas as pd
import numpy as np

# ============================================================
# LOAD MODEL
# ============================================================

print("=" * 80)
print("MODEL UNIT TESTING")
print("=" * 80)

try:

    model = joblib.load("revenue_forecast_model.pkl")

    print("\nMODEL LOADING TEST")

    print("Model Loaded Successfully")

except Exception as e:

    print(f"MODEL LOADING FAILED : {e}")

# ============================================================
# CREATE SAMPLE INPUT
# ============================================================

sample_input = pd.DataFrame({

    "Lag_1": [5000],
    "Lag_7": [7000],
    "Lag_14": [6500],
    "Rolling_Mean_7": [6200],
    "Rolling_STD_7": [500],
    "Month": [6],
    "Quarter": [2],
    "Weekday": [3],
    "DayOfYear": [180],
    "Country_Code": [5]
})

# ============================================================
# PREDICTION TEST
# ============================================================

try:

    prediction = model.predict(sample_input)

    print("\nPREDICTION TEST")

    print(f"Prediction Output : {prediction}")

    # ========================================================
    # VALIDATE OUTPUT
    # ========================================================

    if isinstance(prediction[0], (int, float, np.integer, np.floating)):

        print("\nPrediction Validation : SUCCESS")

    else:

        print("\nPrediction Validation : FAILED")

except Exception as e:

    print(f"PREDICTION TEST FAILED : {e}")

print("\n" + "=" * 80)
print("MODEL TESTING COMPLETED")
print("=" * 80)